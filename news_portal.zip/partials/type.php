<?php

interface USERTYPE
	{
	   const ADMIN = 1;
       const VIEWER = 2;

       const TYPE = [
       		"1" => 'admin',
       		"2" => 'viewer'
       ];
	}
?>